<?php
session_start();
require_once "../bl/usermanager.php";
require_once "../helper/sendEmail.php"; 

$manager = new usermanager();
$choice = $_POST['choice'] ?? '';

// 1. LOGIN
if ($choice == "login") {
    $fn = $_POST['fn'] ?? '';
    $ln = $_POST['ln'] ?? '';
    $res = $manager->login($fn, $ln);

    if ($res) {
        $name = htmlspecialchars("$fn $ln");
        $date = date('F j, Y \a\t g:i A');

        $body = "
        <div style='font-family: Arial, sans-serif; max-width: 600px; margin: auto; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden;'>
            <div style='background-color: #1a1a2e; padding: 30px; text-align: center;'>
                <h1 style='color: #F2B705; margin: 0; font-size: 22px; letter-spacing: 2px;'>MIFFY CHESS CUP</h1>
                <p style='color: #aaa; margin: 5px 0 0; font-size: 13px; letter-spacing: 1px;'>Tournament Portal</p>
            </div>
            <div style='padding: 30px; background: #fff;'>
                <h2 style='color: #1a1a2e; margin-top: 0;'>Login Notification</h2>
                <p style='color: #555; font-size: 15px;'>A player has just logged in to the tournament portal.</p>
                <table style='width: 100%; border-collapse: collapse; margin-top: 20px;'>
                    <tr>
                        <td style='padding: 12px 15px; background: #f9f9f9; border: 1px solid #e0e0e0; color: #888; font-size: 13px; width: 35%;'>Player Name</td>
                        <td style='padding: 12px 15px; border: 1px solid #e0e0e0; color: #1a1a2e; font-weight: bold;'>$name</td>
                    </tr>
                    <tr>
                        <td style='padding: 12px 15px; background: #f9f9f9; border: 1px solid #e0e0e0; color: #888; font-size: 13px;'>Date &amp; Time</td>
                        <td style='padding: 12px 15px; border: 1px solid #e0e0e0; color: #1a1a2e;'>$date</td>
                    </tr>
                </table>
            </div>
            <div style='background: #f4f4f4; padding: 15px; text-align: center;'>
                <p style='color: #aaa; font-size: 12px; margin: 0;'>This is an automated notification from Miffy Chess Cup Tournament System.</p>
            </div>
        </div>";

        sendEmail("peyttabungar@gmail.com", "Admin", "Player Login Alert: $name", $body);
        echo "true";
    } else {
        echo "false";
    }
    exit();
}

// 2. REGISTER PLAYER (WITH EMAIL)
if ($choice == "registerPlayer") {
    $fn = $_POST['fn'] ?? '';
    $ln = $_POST['ln'] ?? '';
    $gd = $_POST['gd'] ?? 'N/A';
    $ag = $_POST['ag'] ?? 0;
    $rt = $_POST['rt'] ?? 0;
    $role = 'Player';

    $res = $manager->registerPlayer($fn, $ln, $gd, $ag, $rt, $role);

    if ($res === true) {
        $name = htmlspecialchars("$fn $ln");
        $gender = htmlspecialchars($gd);
        $date = date('F j, Y \a\t g:i A');

        $body = "
        <div style='font-family: Arial, sans-serif; max-width: 600px; margin: auto; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden;'>
            <div style='background-color: #1a1a2e; padding: 30px; text-align: center;'>
                <h1 style='color: #F2B705; margin: 0; font-size: 22px; letter-spacing: 2px;'>MIFFY CHESS CUP</h1>
                <p style='color: #aaa; margin: 5px 0 0; font-size: 13px; letter-spacing: 1px;'>Tournament Portal</p>
            </div>
            <div style='padding: 30px; background: #fff;'>
                <h2 style='color: #1a1a2e; margin-top: 0;'>New Player Registered</h2>
                <p style='color: #555; font-size: 15px;'>A new player has successfully registered for the tournament.</p>
                <table style='width: 100%; border-collapse: collapse; margin-top: 20px;'>
                    <tr>
                        <td style='padding: 12px 15px; background: #f9f9f9; border: 1px solid #e0e0e0; color: #888; font-size: 13px; width: 35%;'>Full Name</td>
                        <td style='padding: 12px 15px; border: 1px solid #e0e0e0; color: #1a1a2e; font-weight: bold;'>$name</td>
                    </tr>
                    <tr>
                        <td style='padding: 12px 15px; background: #f9f9f9; border: 1px solid #e0e0e0; color: #888; font-size: 13px;'>Gender</td>
                        <td style='padding: 12px 15px; border: 1px solid #e0e0e0; color: #1a1a2e;'>$gender</td>
                    </tr>
                    <tr>
                        <td style='padding: 12px 15px; background: #f9f9f9; border: 1px solid #e0e0e0; color: #888; font-size: 13px;'>Age</td>
                        <td style='padding: 12px 15px; border: 1px solid #e0e0e0; color: #1a1a2e;'>$ag</td>
                    </tr>
                    <tr>
                        <td style='padding: 12px 15px; background: #f9f9f9; border: 1px solid #e0e0e0; color: #888; font-size: 13px;'>FIDE Rating</td>
                        <td style='padding: 12px 15px; border: 1px solid #e0e0e0; color: #1a1a2e;'>$rt</td>
                    </tr>
                    <tr>
                        <td style='padding: 12px 15px; background: #f9f9f9; border: 1px solid #e0e0e0; color: #888; font-size: 13px;'>Registered On</td>
                        <td style='padding: 12px 15px; border: 1px solid #e0e0e0; color: #1a1a2e;'>$date</td>
                    </tr>
                </table>
            </div>
            <div style='background: #f4f4f4; padding: 15px; text-align: center;'>
                <p style='color: #aaa; font-size: 12px; margin: 0;'>This is an automated notification from Miffy Chess Cup Tournament System.</p>
            </div>
        </div>";

        sendEmail("miffycctourna@gmail.com", "Admin", "New Player Registered: $name", $body);

        ob_clean();
        echo "true";
    } else {
        echo $res;
    }
    exit();
}

// 3. REGISTER ADMIN
if ($choice == "registerAdmin") {
    $fn = $_POST['fn'] ?? '';
    $ln = $_POST['ln'] ?? '';
    $id = rand(100000, 999999);
    $role = 'Admin';

    $res = $manager->registerAdminFunc($id, $fn, $ln, $role);

    if ($res === true) {
        $_SESSION['user'] = [
            'userID' => $id,
            'firstName' => $fn,
            'lastName' => $ln,
            'role' => $role
        ];
        echo "true";
    } else {
        echo $res;
    }
    exit();
}

// 4. UPDATE USER
if ($choice == "updateUser") {
    $id = $_POST['id'] ?? 0;
    $fn = $_POST['fn'] ?? '';
    $ln = $_POST['ln'] ?? '';
    $ag = $_POST['ag'] ?? 0;
    $rt = $_POST['rt'] ?? 0;

    echo $manager->updateUserFunc($id, $fn, $ln, $ag, $rt) ? "true" : "false";
    exit();
}

// 5. DELETE PLAYER
if ($choice == "deletePlayer") {
    $id = $_POST['userID'] ?? 0;
    echo $manager->deleteUser($id) ? "true" : "false";
    exit();
}

// 6. GENERATE PAIRS
if ($choice == 'generatePairs') {
    $round = $_POST['round'] ?? 1;
    $user = $_SESSION['user'] ?? null;
    $isAdmin = (isset($user['role']) && strcasecmp($user['role'], 'Admin') == 0);

    if (!$isAdmin) {
        die("Unauthorized: Admin access only.");
    }

    $res = $manager->generatePairingFunc($round);
    ob_clean();
    echo ($res === true) ? "true" : $res;
    exit();
}

// 7. UPDATE SCORE
if ($choice == 'updateScore') {
    $mid = $_POST['mID'] ?? 0;
    $s1  = $_POST['s1'] ?? 0;
    $s2  = $_POST['s2'] ?? 0;

    $res = $manager->updateScoreFunc($mid, $s1, $s2);

    if ($res === "true" || $res === true) {
        echo "true";
    } else {
        echo $res;
    }
    exit();
}

// 8. RESET TOURNAMENT
if ($choice == 'resetTournament') {
    $res = $manager->resetTournamentFunc();
    echo ($res === true) ? "true" : $res;
    exit();
}
?>
