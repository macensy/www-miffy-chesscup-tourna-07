<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Access | Miffy Chess Cup</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;900&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Space Grotesk', sans-serif;
            background: linear-gradient(rgba(20, 15, 10, 0.85), rgba(20, 15, 10, 0.85)), 
                        url('https://i.pinimg.com/1200x/3e/61/10/3e611090fe833da3f7479bbe90e04df5.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
        }
        .admin-card {
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(15px);
            padding: 40px;
            width: 100%;
            max-width: 400px;
            border-radius: 20px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
            text-align: center;
            color: white;
        }
        .miffy-logo {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: white;
            padding: 8px;
            margin-bottom: 15px;
        }
        .admin-title {
            font-weight: 900;
            font-size: 1.8rem;
            text-transform: uppercase;
            color: #F2B705;
            margin-bottom: 0;
        }
        .admin-sub {
            color: rgba(255, 255, 255, 0.5);
            font-size: 0.75rem;
            letter-spacing: 2px;
            margin-bottom: 25px;
            text-transform: uppercase;
        }

    
        .input-field {
            margin-top: 0.5rem !important;  
            margin-bottom: 0.5rem !important;
            text-align: left;
        }
        .input-field input {
            color: white !important;
            border-bottom: 1px solid rgba(255,255,255,0.3) !important;
            margin-bottom: 5px !important;
        }
        .input-field label.active {
            color: #F2B705 !important;
            transform: translateY(-12px) scale(0.8) !important;
            transform-origin: 0 0 !important;
            font-weight: 900;
            font-size: 1rem;
        }
        .input-field input:focus {
            border-bottom: 1px solid #F2B705 !important;
            box-shadow: 0 1px 0 0 #F2B705 !important;
        }
        /* --- END OF COMPACT DESIGN --- */

        .btn-register-admin {
            background: #F2B705 !important;
            color: #1a1a1a !important;
            width: 100%;
            height: 50px;
            font-weight: 900;
            border-radius: 30px;
            margin-top: 20px;
            border: none;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: 0.3s;
            cursor: pointer;
        }
        .btn-register-admin:hover {
            transform: translateY(-3px);
            background: #ffc107 !important;
            box-shadow: 0 10px 20px rgba(242, 183, 5, 0.3);
        }
        .back-link {
            display: block;
            margin-top: 20px;
            color: rgba(255,255,255,0.4);
            text-decoration: none;
            font-size: 0.85rem;
        }
    </style>
</head>
<body>
    <div class="admin-card">
        <img src="../assets/miffy.jpg" class="miffy-logo">
        <div class="admin-title">Admin Portal</div>
        <div class="admin-sub">Authorized Personnel Only</div>
        
        <div class="row" style="margin-bottom: 0;">
            <div class="input-field col s12">
                <input id="AdminFName" type="text" 
                       minlength="2" maxlength="50"
                       oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '');">
                <label for="AdminFName" class="active">First Name</label>
            </div>
            
            <div class="input-field col s12">
                <input id="AdminLName" type="text" 
                       minlength="2" maxlength="50"
                       oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '');">
                <label for="AdminLName" class="active">Last Name</label>
            </div>
            
            <div class="input-field col s12">
                <input id="AdminSecretKey" type="password">
                <label for="AdminSecretKey" class="active">Secret Arbiter Key</label>
            </div>
        </div>
        
        <button class="btn-register-admin waves-effect waves-light" onclick="registerAdmin()">
            Login Admin Account
        </button>
        <a href="loginpage.php" class="back-link">Return to Login</a>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
    function registerAdmin() {
        let fn = $('#AdminFName').val();
        let ln = $('#AdminLName').val();
        let key = $('#AdminSecretKey').val();

        if (!fn || !ln || !key) {
            Swal.fire("Wait", "Complete the details, boi!", "warning");
            return;
        }
        
        if (fn.length < 2 || ln.length < 2) {
            Swal.fire("Wait", "Names are too short!", "warning");
            return;
        }

        if (key !== "miffyandboris") {
            Swal.fire("Unauthorized", "Invalid Secret Key!", "error");
            return;
        }

        let data = {
            choice: 'registerAdmin', 
            fn: fn,
            ln: ln
        };

        $.post('../controllers/controller.php', data, function(res) {
            if (res.trim() === "true") {
                Swal.fire({
                    title: "ADMIN VERIFIED!",
                    text: "Welcome, Arbiter. Redirecting...",
                    icon: "success",
                    timer: 1500,
                    showConfirmButton: false
                }).then(() => {
                    window.location.href = "dashboardpage.php"; 
                });
            } else {
                Swal.fire("Error", "Check your database connection.", "error");
            }
        }).fail(function() {
            Swal.fire("System Error", "Cannot connect to server.", "error");
        });
    }
    </script>
</body>
</html>