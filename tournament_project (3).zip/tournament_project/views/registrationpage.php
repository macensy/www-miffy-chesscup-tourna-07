<?php
session_start();
require_once "../bl/usermanager.php";
$manager = new usermanager();
$players = $manager->getUser();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Join Tournament | Miffy Chess Cup</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;900&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Space Grotesk', sans-serif;
            background: linear-gradient(rgba(20, 15, 10, 0.85), rgba(20, 15, 10, 0.85)), 
                        url('https://i.pinimg.com/1200x/3e/61/10/3e611090fe833da3f7479bbe90e04df5.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            padding: 20px;
        }
        .reg-container {
            background: rgba(255, 255, 255, 0.07);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            padding: 40px;
            width: 100%;
            max-width: 900px;
            border-radius: 25px;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.6);
            color: white;
        }
        .logo-circle {
            width: 90px;
            height: 100px;
            border-radius: 50%;
            background: white;
            padding: 8px;
            margin-bottom: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }
        .section-title {
            font-weight: 900;
            font-size: 2.2rem;
            text-transform: uppercase;
            color: #F2B705;
            margin-bottom: 5px;
        }
        .section-sub {
            color: rgba(255, 255, 255, 0.6);
            letter-spacing: 2px;
            margin-bottom: 30px;
            text-transform: uppercase;
            font-size: 0.8rem;
        }
        .input-field input, .input-field select {
            color: white !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.3) !important;
        }
        .input-field label.active {
            color: #F2B705 !important;
            transform: translateY(-14px) scale(0.8) !important;
            transform-origin: 0 0 !important;
        }
        .input-field input:focus {
            border-bottom: 1px solid #F2B705 !important;
            box-shadow: 0 1px 0 0 #F2B705 !important;
        }
        .custom-select {
            background: rgba(0, 0, 0, 0.2);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            padding: 10px;
            margin-top: 10px;
        }
        .btn-register {
            background: #F2B705 !important;
            color: #1a1a1a !important;
            width: 100%;
            height: 55px;
            font-weight: 900;
            font-size: 1.2rem;
            border-radius: 30px;
            margin-top: 20px;
            transition: 0.3s;
            border: none;
        }
        .btn-register:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(242, 183, 5, 0.3);
        }
        .player-list {
            background: rgba(0, 0, 0, 0.2);
            border-radius: 15px;
            padding: 15px;
            max-height: 400px;
            overflow-y: auto;
        }
        .back-to-home {
            display: inline-block;
            margin-top: 25px;
            color: #F2B705;
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</head>
<body>
    
    <div class="reg-container">
        <div class="row" style="margin-bottom: 0;">
            <div class="col s12 m6" style="padding: 20px; border-right: 1px solid rgba(255,255,255,0.1);">
                <center>
                    <img src="../assets/miffy.jpg" class="logo-circle">
                    <div class="section-title">Register</div>
                    <div class="section-sub">Join Now!</div>
                </center>
                
                <div class="row">
                    <div class="input-field col s6">
                        <input type="text" id="FName" minlength="2" maxlength="50" oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '');">
                        <label class="active">First Name</label>
                    </div>
                    <div class="input-field col s6">
                        <input type="text" id="LName" minlength="2" maxlength="50" oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '');">
                        <label class="active">Last Name</label>
                    </div>
                </div>

                <label style="color: rgba(255,255,255,0.7);">Gender</label>
                <select id="Gender" class="browser-default custom-select">
                    <option value="" disabled selected>Choose Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>

                <div class="row" style="margin-top:20px;">
                    <div class="input-field col s6">
                        <input type="number" id="Age" oninput="if(this.value.length > 2) this.value = this.value.slice(0,2);">
                        <label class="active">Age</label>
                    </div>
                    <div class="input-field col s6">
                        <input type="number" id="Rating" oninput="if(this.value.length > 4) this.value = this.value.slice(0,4);">
                        <label class="active">FIDE Rating</label>
                    </div>
                </div>


                <button class="btn-register waves-effect waves-light" onclick="addFunc()">
                    Submit Player
                </button>
                <center><a href="miffytourna.php" class="back-to-home">← Back to Home</a></center>
            </div>

            <div class="col s12 m6" style="padding: 20px;">
                <div style="text-align: center; margin-bottom: 20px;">
                    <span style="font-weight: 900; color: #fff; text-transform: uppercase;">REGISTERED PLAYERS</span>
                </div>
                <div class="player-list">
                    <table class="highlight">
                        <thead style="color: #F2B705;">
                            <tr>
                                <th>Name</th>
                                <th>Age</th>
                                <th>Rating</th>
                            </tr>
                        </thead>
                        <tbody style="color: rgba(255,255,255,0.8);">
                            <?php foreach($players as $p): ?>
                            <tr>
                                <td><?= strtoupper($p['firstName'] . ' ' . $p['lastName']) ?></td>
                                <td><?= $p['age'] ?></td>
                                <td style="color: #F2B705; font-weight: bold;"><?= $p['rating'] ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="../script/service.js"></script>
</body>
</html>