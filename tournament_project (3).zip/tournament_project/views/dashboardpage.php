<?php
session_start();
if (!isset($_SESSION['user'])) { header("Location: loginpage.php"); exit(); }
require_once "../bl/usermanager.php";

$manager = new usermanager();
$currentRound = isset($_GET['round']) ? (int)$_GET['round'] : 1; 

$user = $_SESSION['user'];
$isAdmin = (isset($user['role']) && $user['role'] == 'Admin') || (strtolower($user['firstName'] ?? '') == 'faith');

// Data retrieval
$adminData = $manager->getAdminDashboardStats($currentRound);
$standings = $manager->getLeaderboards() ?? []; 
$pairings = $manager->getPairings($currentRound) ?? []; 

$nextRoundToGenerate = 1;
if (!empty($standings)) {
    $db = (new Database())->connectDB();
    $stmt = $db->query("SELECT MAX(round_num) as max_r FROM tbl_pairing");
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row && $row['max_r']) {
        $nextRoundToGenerate = $row['max_r'] + 1;
    }
}

// Chart Data (Top 5)
$chartLabels = [];
$chartData = [];
foreach(array_slice($standings, 0, 5) as $s) {
    $chartLabels[] = strtoupper($s['firstName']);
    $chartData[] = (float)$s['total_pts'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard | Miffy Chess Cup</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0"></script>
    <style>
        body {
            font-family: 'Space Grotesk', sans-serif;
            background: linear-gradient(rgba(20, 15, 10, 0.9), rgba(20, 15, 10, 0.9)), 
                        url('https://i.pinimg.com/736x/64/de/51/64de5126d1398692e1c52a44f1e8ced0.jpg');
            background-size: cover; background-position: center; background-attachment: fixed;
            min-height: 100vh; color: white; margin: 0; padding-bottom: 50px;
        }
        .glass-card {
            background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(15px);
            border-radius: 20px; padding: 30px; margin-top: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.5); border: 1px solid rgba(255,255,255,0.1);
        }
        .header-section {
            display: flex; align-items: center; justify-content: space-between;
            margin-bottom: 20px; padding: 20px 0; border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .miffy-logo-small {
            width: 70px; height: 70px; border-radius: 50%;
            background: white; padding: 5px; margin-right: 15px; border: 3px solid #FDFD96;
        }
        .dash-title { font-weight: 900; font-size: 1.8rem; color: #FDFD96; margin: 0; }
        .btn-gold { background: #FDFD96 !important; color: #1a1a1a !important; font-weight: 900; border-radius: 10px; }
        .score-input {
            background: rgba(0,0,0,0.3) !important; border: 1px solid rgba(253,253,150,0.5) !important;
            color: white !important; text-align: center; width: 45px !important; height: 30px !important;
            margin: 0 !important; border-radius: 5px;
        }
        thead th { color: #FDFD96; text-transform: uppercase; letter-spacing: 2px; font-size: 0.8rem; }
        .nav-link { color: #FDFD96; font-weight: bold; margin-right: 20px; text-transform: uppercase; }

        .elegant-stat-card {
            background: rgba(255, 255, 255, 0.03); backdrop-filter: blur(12px);
            border-radius: 20px; padding: 20px 10px; border: 1px solid rgba(255, 255, 255, 0.08);
            text-align: center; box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        .stat-label { color: #FDFD96; text-transform: uppercase; letter-spacing: 3px; font-size: 0.65rem; font-weight: 300; display: block; margin-bottom: 8px; opacity: 0.8; }
        .stat-line { width: 25px; height: 1px; background: rgba(253, 253, 150, 0.4); margin: 0 auto 12px auto; }
        .stat-value { font-size: 2.2rem; font-weight: 200; color: #FDFD96; margin: 0; }
    </style>
</head>
<body>
<div class="container">
    <div class="header-section">
        <div style="display: flex; align-items: center;">
            <img src="../assets/miffy.jpg" class="miffy-logo-small">
            <div>
                <h1 class="dash-title">MIFFY CHESS CUP</h1>
                <span style="font-size: 0.8rem; color: rgba(255,255,255,0.5);">
                    LOGGED IN AS: <b style="color:white;"><?= strtoupper($user['firstName'] ?? 'USER') ?></b> 
                    (<?= $isAdmin ? 'ADMIN' : 'PLAYER' ?>)
                </span>
            </div>
        </div>
        <div>
            <a href="playerspage.php" class="nav-link">Players List</a>
            <a href="logout.php" class="btn-gold btn waves-effect">Logout</a>
        </div>
    </div>

    <?php if($isAdmin): ?>
    <div class="row">
        <div class="col s12 m4"><div class="elegant-stat-card"><span class="stat-label">Registered Players</span><div class="stat-line"></div><h2 class="stat-value"><?= $adminData['registered_players'] ?></h2></div></div>
        <div class="col s12 m4"><div class="elegant-stat-card"><span class="stat-label">Unfinished Matches</span><div class="stat-line"></div><h2 class="stat-value"><?= $adminData['unfinished_matches'] ?></h2></div></div>
        <div class="col s12 m4"><div class="elegant-stat-card"><span class="stat-label">Rounds Completed</span><div class="stat-line"></div><h2 class="stat-value"><?= $adminData['completed_rounds'] ?></h2></div></div>
    </div>
    <?php endif; ?>

    <div class="row">
        <div class="col s12 m4">
            <div class="glass-card">
                <h5 style="font-weight: 900; color: #FDFD96; margin-top: 0;">STANDINGS</h5>
                <table class="centered">
                    <thead><tr><th>Rank</th><th>Player</th><th>Pts</th></tr></thead>
                    <tbody>
                        <?php $rank = 1; foreach($standings as $s): ?>
                        <tr>
                            <td style="font-weight:900; color:#FDFD96;"><?=$rank++?></td>
                            <td><?=strtoupper($s['firstName'])?></td>
                            <td style="background:rgba(253,253,150,0.2);"><?= $s['total_pts'] ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php if($isAdmin): ?>
            <div class="glass-card center-align">
                <h6 style="color: #FDFD96; font-weight: 900; letter-spacing: 2px;">PLAYER RATIO</h6>
                <div style="height: 250px; margin-top: 20px;">
                    <canvas id="ratioChart"></canvas>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <div class="col s12 m8">
            <div class="glass-card">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                    <h5 style="font-weight: 900; color: #FDFD96; margin: 0; letter-spacing: 2px;">PAIRING</h5>
                    <?php if($isAdmin): ?>
                    <div style="display: flex; gap: 8px;">
                        <button onclick="generatePairs(<?= $nextRoundToGenerate ?>)" class="btn-small btn-gold waves-effect"><i class="material-icons left">bolt</i> GENERATE</button>
                        <button onclick="resetTournament()" class="btn-small waves-effect red darken-4"><i class="material-icons left">history</i> RESET</button>
                    </div>
                    <?php endif; ?>
                </div>

                <div style="margin-bottom: 25px; display: flex; flex-wrap: wrap; gap: 8px; justify-content: center;">
                    <?php for($r = 1; $r <= 7; $r++): ?>
                    <a href="?round=<?= $r ?>" class="btn-small <?= $currentRound == $r ? 'btn-gold' : 'grey darken-3' ?>" style="border-radius: 5px; font-weight: 800; min-width: 45px;">R<?= $r ?></a>
                    <?php endfor; ?>
                </div>

                <table style="width: 100%;">
                    <thead><tr><th>WHITE</th><th>RESULT</th><th>BLACK</th></tr></thead>
                    <tbody>
                        <?php if(empty($pairings)): ?>
                        <tr><td colspan="3" style="text-align:center; padding: 40px; color: rgba(255,255,255,0.2);">No matches for Round <?= $currentRound ?>.</td></tr>
                        <?php else: ?>
                        <?php foreach($pairings as $m): ?>
                        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                            <td style="text-align: center; font-weight: 700; padding: 15px 0;"><?= strtoupper($m['p1Name']) ?></td>
                            <td style="text-align: center;">
                                <div style="display: flex; align-items: center; justify-content: center; gap: 10px;">
                                    <?php if($isAdmin): ?>
                                    <input type="number" id="score1_<?= (int)$m['match_id'] ?>" value="<?= $m['p1_score'] ?>" class="score-input" min="0" max="1" step="0.5">
                                    <span style="color: #FDFD96; font-weight: bold;">-</span>
                                    <input type="number" id="score2_<?= (int)$m['match_id'] ?>" value="<?= $m['p2_score'] ?>" class="score-input" min="0" max="1" step="0.5">
                                    <button onclick="updateScore(<?= (int)$m['match_id'] ?>)" class="btn-floating btn-small btn-gold"><i class="material-icons">save</i></button>
                                    <?php else: ?>
                                    <span style="font-size: 1.2rem; font-weight: 900; color: #FDFD96;"><?= $m['p1_score'] ?> - <?= $m['p2_score'] ?></span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td style="text-align: center; font-weight: 700; padding: 15px 0;"><?= strtoupper($m['p2Name']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if($isAdmin): ?>
            <div class="glass-card" style="padding: 40px;">
                <h5 style="color: #FDFD96; font-weight: 900; text-align: center; margin-bottom: 30px;">TOP 5 PROGRESS</h5>
                <div style="height: 400px; width: 100%;">
                    <canvas id="performanceChart"></canvas>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="../script/service.js"></script>

<script>
    Chart.register(ChartDataLabels); 

    document.addEventListener('DOMContentLoaded', function() {
        <?php if($isAdmin): ?>
        // Ratio Chart
        const ratioCtx = document.getElementById('ratioChart').getContext('2d');
        new Chart(ratioCtx, {
            type: 'pie',
            data: {
                labels: ['Male', 'Female'],
                datasets: [{
                    data: [<?= $adminData['male_count'] ?? 0 ?>, <?= $adminData['female_count'] ?? 0 ?>],
                    backgroundColor: ['#2196F3', '#E91E63'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom', labels: { color: '#fff', padding: 20 } },
                    datalabels: {
                        color: '#fff',
                        font: { weight: 'bold', size: 14 },
                        formatter: (value, ctx) => {
                            let sum = 0;
                            let dataArr = ctx.chart.data.datasets[0].data;
                            dataArr.map(data => { sum += data; });
                            if (sum === 0) return "0%";
                            let percentage = (value * 100 / sum).toFixed(1) + "%";
                            return percentage;
                        }
                    }
                }
            }
        });

        // Bar Chart
        const perfCtx = document.getElementById('performanceChart').getContext('2d');
        new Chart(perfCtx, {
            type: 'bar',
            data: {
                labels: <?= json_encode($chartLabels) ?>,
                datasets: [{
                    label: 'Total Points',
                    data: <?= json_encode($chartData) ?>,
                    backgroundColor: '#F2B705',
                    borderRadius: 10,
                    barThickness: 60
                }]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                scales: {
                    y: { beginAtZero: true, grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#FDFD96', font: { size: 14, weight: 'bold' } } },
                    x: { grid: { display: false }, ticks: { color: '#fff', font: { size: 12, weight: '900' } } }
                },
                plugins: { 
                    legend: { display: false },
                    datalabels: { display: false }
                }
            }
        });
        <?php endif; ?>
    });
</script>
</body>
</html>