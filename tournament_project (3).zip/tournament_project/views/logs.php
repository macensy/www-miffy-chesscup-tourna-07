<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['user'])) { header("Location: loginpage.php"); exit(); }
require_once "../bl/usermanager.php";
$manager = new usermanager();
$logs = $manager->getLogs(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>System Logs | Chess Pro</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body class="grey lighten-3">
    <nav class="blue-grey darken-4">
        <div class="nav-wrapper container">
            <a href="dashboard.php" class="brand-logo">Activity Logs</a>
            <ul class="right">
                <li><a href="dashboard.php" class="btn blue darken-2">Back to Dashboard</a></li>
            </ul>
        </div>
    </nav>
    <div class="container" style="margin-top: 30px;">
        <div class="card z-depth-3">
            <div class="card-content">
                <table class="striped responsive-table">
                    <thead>
                        <tr class="blue-grey lighten-5">
                            <th>Timestamp</th>
                            <th>Admin/User</th>
                            <th>Activity Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($logs as $l): ?>
                        <tr>
                            <td class="grey-text text-darken-1">
                                <?= date('Y-m-d H:i A', strtotime($l['created_at'])) ?>
                            </td>
                            <td><b><?= $l['firstName'] . " " . $l['lastName'] ?></b></td>
                            <td>
                                <span class="chip blue-text text-darken-4">
                                    <i class="material-icons tiny left">info</i><?= $l['action'] ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>