<?php
session_start();
if (!isset($_SESSION['user'])) { header("Location: loginpage.php"); exit(); }
require_once "../bl/usermanager.php";
$manager = new usermanager();
$user = $_SESSION['user'];
$allPlayers = $manager->getUser();
$isAdmin = (isset($user['role']) && $user['role'] == 'Admin') || (strtolower($user['firstName']) == 'faith');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Players List | Miffy Chess Cup</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;900&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Space Grotesk', sans-serif;
            background: linear-gradient(rgba(20, 15, 10, 0.9), rgba(20, 15, 10, 0.9)), 
                        url('https://i.pinimg.com/736x/64/de/51/64de5126d1398692e1c52a44f1e8ced0.jpg');
            background-size: cover; background-position: center; background-attachment: fixed;
            min-height: 100vh; color: white; margin: 0; padding-bottom: 50px;
        }
        .glass-card {
            background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(15px);
            border-radius: 20px; padding: 30px; margin-top: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.5); border: 1px solid rgba(255,255,255,0.1);
        }
        .header-section {
            display: flex; align-items: center; justify-content: space-between;
            margin-bottom: 30px; padding: 20px; border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .dash-title { font-weight: 900; font-size: 1.8rem; color: #F2B705; margin: 0; }
        .btn-gold { background: #F2B705 !important; color: #1a1a1a !important; font-weight: 900; border-radius: 10px; }
        table.highlight tbody tr:hover { background: rgba(255, 255, 255, 0.1) !important; }
        thead th { color: #F2B705; text-transform: uppercase; letter-spacing: 2px; }
        
        /* Modal Style */
        .modal { 
            background: rgba(30, 30, 30, 0.98) !important; 
            backdrop-filter: blur(10px); 
            border-radius: 20px; 
            border: 1px solid #F2B705;
            color: white;
            max-width: 500px;
        }
        .modal .input-field { margin-top: 1.5rem; }
        .modal .input-field label.active { color: #F2B705 !important; font-weight: bold; }
        .modal .input-field input { color: white !important; border-bottom: 1px solid rgba(255,255,255,0.3) !important; }
        .modal .input-field input:focus { border-bottom: 1px solid #F2B705 !important; box-shadow: 0 1px 0 0 #F2B705 !important; }
    </style>
</head>
<body>
<div class="container">
    <div class="header-section">
        <div style="display: flex; align-items: center;">
            <a href="dashboardpage.php" style="color: #F2B705; margin-right: 15px;"><i class="material-icons">arrow_back</i></a>
            <div>
                <h1 class="dash-title">PLAYER REGISTRY</h1>
                <span style="font-size: 0.8rem; color: rgba(255,255,255,0.5);">MANAGE TOURNAMENT PARTICIPANTS</span>
            </div>
        </div>
        <div>
            <a href="registrationpage.php" class="btn-gold btn waves-effect">+ NEW PLAYER</a>
        </div>
    </div>

    <div class="glass-card">
        <table class="centered highlight responsive-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>Gender</th>
                    <th>Age</th>
                    <th>Rating</th>
                    <?php if($isAdmin): ?><th>Actions</th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach($allPlayers as $p): ?>
                <tr>
                    <td><span style="color: #F2B705;">#<?=$p['userID']?></span></td>
                    <td style="font-weight:bold;"><?=strtoupper($p['firstName'].' '.$p['lastName'])?></td>
                    <td><?=$p['gender']?></td>
                    <td><?=$p['age']?></td>
                    <td style="font-weight:900; color: #F2B705;"><?=$p['rating']?></td>
                    <?php if($isAdmin): ?>
                    <td>
                        <button class="btn-small blue darken-3 waves-effect" style="border-radius:5px;" 
                                onclick="openEditModal('<?=$p['userID']?>','<?=$p['firstName']?>','<?=$p['lastName']?>','<?=$p['age']?>','<?=$p['rating']?>')">
                            <i class="material-icons">edit</i>
                        </button>
                        <button class="btn-small red darken-4 waves-effect" style="border-radius:5px;" onclick="deleteFunc(<?=$p['userID']?>)">
                            <i class="material-icons">delete</i>
                        </button>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div id="modalEdit" class="modal">
    <div class="modal-content">
        <h4 style="font-weight:900; color:#F2B705;">UPDATE PLAYER</h4>
        <div class="row">
            <input type="hidden" id="editID">
            <div class="input-field col s12 m6">
                <input type="text" id="editFName" 
                       oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '').slice(0,50);">
                <label class="active">First Name (2-50)</label>
            </div>
            <div class="input-field col s12 m6">
                <input type="text" id="editLName" 
                       oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '').slice(0,50);">
                <label class="active">Last Name (2-50)</label>
            </div>
            <div class="input-field col s12 m6">
                <input type="number" id="editAge" 
                       oninput="if(this.value.length > 2) this.value = this.value.slice(0,2);">
                <label class="active">Age (Max 99)</label>
            </div>
            <div class="input-field col s12 m6">
                <input type="number" id="editRating" 
                       oninput="if(this.value.length > 4) this.value = this.value.slice(0,4);">
                <label class="active">FIDE Rating (Max 9999)</label>
            </div>
        </div>
    </div>
    <div class="modal-footer" style="background: transparent; padding-right: 25px; padding-bottom: 20px;">
        <button class="btn green accent-4 waves-effect" style="font-weight:900;" onclick="updateFunc()">SAVE CHANGES</button>
        <a href="#!" class="modal-close btn-flat white-text">CANCEL</a>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="../script/service.js"></script>
<script>
    $(document).ready(function(){
        $('.modal').modal();
    });

    function openEditModal(id, fn, ln, ag, rt) {
        $('#editID').val(id);
        $('#editFName').val(fn);
        $('#editLName').val(ln);
        $('#editAge').val(ag);
        $('#editRating').val(rt);
        M.updateTextFields();
        $('#modalEdit').modal('open');
    }
</script>
</body>
</html>