<?php
session_start();
require_once "../bl/usermanager.php";

$manager = new usermanager();
$choice = $_POST['choice'] ?? '';

if ($choice == "login") {
    $fn = $_POST['fn'] ?? '';
    $ln = $_POST['ln'] ?? '';
    $res = $manager->login($fn, $ln);
    echo ($res) ? "true" : "false";
    exit();
}

if ($choice == "registerPlayer") {
    $fn = $_POST['fn'] ?? '';
    $ln = $_POST['ln'] ?? '';
    $gd = $_POST['gd'] ?? 'N/A';
    $ag = $_POST['ag'] ?? 0;
    $rt = $_POST['rt'] ?? 0;
    $role = 'Player'; 

    $res = $manager->registerPlayer($fn, $ln, $gd, $ag, $rt, $role);
    
    if ($res === true) {
        echo "true";
    } else {
        echo $res; 
    }
    exit();
}

if ($choice == "registerAdmin") {
    $fn = $_POST['fn'] ?? '';
    $ln = $_POST['ln'] ?? '';
    $id = rand(100000, 999999); 
    $role = 'Admin';

    $res = $manager->registerAdminFunc($id, $fn, $ln, $role);

    if ($res === true) {
        $_SESSION['user'] = [
            'userID' => $id,
            'firstName' => $fn,
            'lastName' => $ln,
            'role' => $role
        ];
        echo "true";
    } else {
        echo $res; 
    }
    exit();
}

if ($choice == "updateUser") {
    $id = $_POST['id'] ?? 0;
    $fn = $_POST['fn'] ?? '';
    $ln = $_POST['ln'] ?? '';
    $ag = $_POST['ag'] ?? 0;
    $rt = $_POST['rt'] ?? 0;
    
    echo $manager->updateUserFunc($id, $fn, $ln, $ag, $rt) ? "true" : "false";
    exit();
}

if ($choice == "deletePlayer") {
    $id = $_POST['userID'] ?? 0;
    echo $manager->deleteUser($id) ? "true" : "false";
    exit();
}

if ($choice == 'generatePairs') {
    $round = $_POST['round'] ?? 1;
    $user = $_SESSION['user'] ?? null;
    $isAdmin = (isset($user['role']) && strcasecmp($user['role'], 'Admin') == 0);

    if (!$isAdmin) { 
        die("Unauthorized: Admin access only."); 
    }

    $res = $manager->generatePairingFunc($round);
    ob_clean(); 
    echo ($res === true) ? "true" : $res;
    exit();
}

if ($choice == 'updateScore') {
    $mid = $_POST['mID'] ?? 0; 
    $s1  = $_POST['s1'] ?? 0;
    $s2  = $_POST['s2'] ?? 0;

    $res = $manager->updateScoreFunc($mid, $s1, $s2);
    
    if ($res === true || $res === "true") {
        $manager->updateStandings();
        echo "true";
    } else {
        echo $res; 
    }
    exit();
}

if ($choice == 'resetTournament') {
    $res = $manager->resetTournamentFunc();
    if ($res === true) {
        echo "true";
    } else {
        echo $res; 
    }
    exit();
}
?>