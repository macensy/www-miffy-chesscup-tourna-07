<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Access | Miffy Chess Cup</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;900&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Space Grotesk', sans-serif;
            background: linear-gradient(rgba(20, 15, 10, 0.85), rgba(20, 15, 10, 0.85)), 
                        url('https://i.pinimg.com/1200x/3e/61/10/3e611090fe833da3f7479bbe90e04df5.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
        }
        .admin-card {
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(15px);
            padding: 50px 40px;
            width: 100%;
            max-width: 450px;
            border-radius: 20px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
            text-align: center;
            color: white;
        }
        .miffy-logo {
            width: 100px;
            height: 110px;
            border-radius: 50%;
            background: white;
            padding: 8px;
            margin-bottom: 20px;
        }
        .admin-title {
            font-weight: 900;
            font-size: 1.8rem;
            text-transform: uppercase;
            color: #F2B705;
            margin-bottom: 5px;
        }
        .admin-sub {
            color: rgba(255, 255, 255, 0.5);
            font-size: 0.8rem;
            letter-spacing: 2px;
            margin-bottom: 30px;
            text-transform: uppercase;
        }
        .input-field input {
            color: white !important;
            border-bottom: 1px solid rgba(255,255,255,0.3) !important;
        }
        .input-field label {
            color: rgba(255,255,255,0.7) !important;
        }
        .btn-register-admin {
            background: #F2B705 !important;
            color: #1a1a1a !important;
            width: 100%;
            height: 55px;
            font-weight: 900;
            border-radius: 30px;
            margin-top: 25px;
            border: none;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: 0.3s;
        }
        .btn-register-admin:hover {
            transform: translateY(-3px);
            background: #ffc107 !important;
        }
        .back-link {
            display: block;
            margin-top: 25px;
            color: rgba(255,255,255,0.4);
            text-decoration: none;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="admin-card">
        <img src="../assets/miffy.jpg" class="miffy-logo">
        <div class="admin-title">Admin Portal</div>
        <div class="admin-sub">Authorized Personnel Only</div>
        <div class="row">
            <div class="input-field col s12">
                <input id="AdminFName" type="text">
                <label for="AdminFName" class="active">First Name</label>
            </div>
            <div class="input-field col s12">
                <input id="AdminLName" type="text">
                <label for="AdminLName" class="active">Last Name</label>
            </div>
            <div class="input-field col s12" style="margin-top: 30px;">
                <input id="AdminSecretKey" type="password" style="border-bottom: 2px solid #F2B705 !important;">
                <label for="AdminSecretKey" style="color: #F2B705 !important;" class="active">Secret Arbiter Key</label>
            </div>
        </div>
        <button class="btn-register-admin waves-effect waves-light" onclick="registerAdmin()">
            Login Admin Account
        </button>
        <a href="loginpage.php" class="back-link">Return to Login</a>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
    function registerAdmin() {
        let fn = $('#AdminFName').val();
        let ln = $('#AdminLName').val();
        let key = $('#AdminSecretKey').val();
        if (!fn || !ln || !key) {
            Swal.fire("Wait", "Fill up all fields, boi!", "warning");
            return;
        }
        if (key !== "miffyandboris") {
            Swal.fire("Unauthorized", "Invalid Secret Key!", "error");
            return;
        }
        let data = {
            choice: 'registerAdmin', 
            fn: fn,
            ln: ln
        };
        $.post('../controllers/controller.php', data, function(res) {
            if (res.trim() === "true") {
                Swal.fire({
                    title: "ADMIN VERIFIED!",
                    text: "Welcome, Arbiter. Redirecting...",
                    icon: "success",
                    timer: 1500,
                    showConfirmButton: false
                }).then(() => {
                    window.location.href = "dashboardpage.php"; 
                });
            } else {
                Swal.fire("Error", "Account creation failed. Check database role column.", "error");
            }
        }).fail(function() {
            Swal.fire("System Error", "Cannot connect to controller.php", "error");
        });
    }
    </script>
</body>
</html>