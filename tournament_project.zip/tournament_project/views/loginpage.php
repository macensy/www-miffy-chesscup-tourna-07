<?php
session_start();
if (isset($_SESSION['user'])) {
    header("Location: dashboardpage.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login | Miffy Chess Cup</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;900&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Space Grotesk', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(rgba(20, 15, 10, 0.82), rgba(20, 15, 10, 0.82)), 
                        url('https://i.pinimg.com/1200x/3e/61/10/3e611090fe833da3f7479bbe90e04df5.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            height: 100vh;
            display: flex;  
            align-items: center;
            justify-content: center;
        }
        .login-container {
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            padding: 50px 40px;
            width: 100%;
            max-width: 420px;
            border-radius: 20px; 
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
            text-align: center;
        }
        .miffy-logo-round {
            width: 110px;
            height: 110px;
            border-radius: 50%;
            background: #fff;
            object-fit: contain;
            padding: 10px;
            margin-bottom: 20px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
        }
        .login-header {
            color: #fff;
            font-weight: 900;
            font-size: 2.2rem;
            margin-bottom: 5px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .login-subtext {
            color: #F2B705;
            font-weight: 500;
            margin-bottom: 35px;
            letter-spacing: 3px;
            font-size: 0.8rem;
            text-transform: uppercase;
        }
        .input-field input {
            color: #fff !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.3) !important;
            transition: 0.3s !important;
        }
        .input-field input:focus {
            border-bottom: 1px solid #F2B705 !important;
            box-shadow: 0 1px 0 0 #F2B705 !important;
        }
        .input-field label {
            color: rgba(255, 255, 255, 0.6) !important;
        }
        .btn-enter {
            background: #F2B705 !important;
            color: #1a1a1a !important;
            width: 100%;
            height: 55px;
            font-weight: 900;
            font-size: 1.1rem;
            border-radius: 30px; 
            border: none;
            margin-top: 30px;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: 0.3s;
        }
        .btn-enter:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(242, 183, 5, 0.3);
            background: #ffc107 !important;
        }
        .footer-nav {
            margin-top: 30px;
            font-size: 0.9rem;
        }
        .footer-nav a {
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            transition: 0.3s;
        }
        .footer-nav a:hover {
            color: #F2B705;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <img src="../assets/miffy.jpg" alt="Miffy" class="miffy-logo-round">
        <div class="login-header">Player Login</div>
        <div class="login-subtext">Tournament Portal</div>
        <div class="input-field">
            <input id="icon_LFName" type="text">
            <label for="icon_LFName" class="active">First Name</label>
        </div>
        <div class="input-field">
            <input id="icon_LLName" type="text">
            <label for="icon_LLName" class="active">Last Name</label>
        </div>
        <button class="btn-enter waves-effect waves-light" onclick="loginFunc()">
            Login Now
        </button>
        <div class="footer-nav">
            <a href="registrationpage.php">No Account?</a>
            <span style="margin: 0 15px; color: rgba(255,255,255,0.2);">|</span>
            <a href="adminreg.php" style="color: #F2B705; font-weight: bold;">Admin Access</a>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="../script/service.js"></script>
</body>
</html>