<?php
session_start();
if (!isset($_SESSION['user'])) { header("Location: loginpage.php"); exit(); }
require_once "../bl/usermanager.php";
$manager = new usermanager();
$user = $_SESSION['user'];
$isAdmin = (isset($user['role']) && $user['role'] == 'Admin') || (strtolower($user['firstName']) == 'faith');
$standings = $manager->getLeaderboards();
$currentRound = $_GET['round'] ?? 1; 
$pairings = $manager->getPairings($currentRound); 
$nextRoundToGenerate = 1;
if (!empty($standings)) {
    $db = (new Database())->connectDB();
    $stmt = $db->query("SELECT MAX(round_num) as max_r FROM tbl_pairing");
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row['max_r']) {
        $nextRoundToGenerate = $row['max_r'] + 1;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard | Miffy Chess Cup</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        body {
            font-family: 'Space Grotesk', sans-serif;
            background: linear-gradient(rgba(20, 15, 10, 0.9), rgba(20, 15, 10, 0.9)), 
                        url('https://i.pinimg.com/736x/64/de/51/64de5126d1398692e1c52a44f1e8ced0.jpg');
            background-size: cover; background-position: center; background-attachment: fixed;
            min-height: 100vh; color: white; margin: 0; padding-bottom: 50px;
        }
        .glass-card {
            background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(15px);
            border-radius: 20px; padding: 30px; margin-top: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.5); border: 1px solid rgba(255,255,255,0.1);
        }
        .header-section {
            display: flex; align-items: center; justify-content: space-between;
            margin-bottom: 40px; padding: 20px; border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .miffy-logo-small {
            width: 70px; height: 70px; border-radius: 50%;
            background: white; padding: 5px; margin-right: 15px; border: 3px solid #F2B705;
        }
        .dash-title { font-weight: 900; font-size: 1.8rem; color: #F2B705; margin: 0; }
        .btn-gold { background: #F2B705 !important; color: #1a1a1a !important; font-weight: 900; border-radius: 10px; }
        .score-input {
            background: rgba(0,0,0,0.3) !important; border: 1px solid rgba(242,183,5,0.5) !important;
            color: white !important; text-align: center; width: 45px !important; height: 30px !important;
            margin: 0 !important; border-radius: 5px;
        }
        thead th { color: #F2B705; text-transform: uppercase; letter-spacing: 2px; font-size: 0.8rem; }
        .nav-link { color: #F2B705; font-weight: bold; margin-right: 20px; text-transform: uppercase; }
    </style>
</head>
<body>
<div class="container">
    <div class="header-section">
        <div style="display: flex; align-items: center;">
            <img src="../assets/miffy.jpg" class="miffy-logo-small">
            <div>
                <h1 class="dash-title">MIFFY CHESS CUP</h1>
                <span style="font-size: 0.8rem; color: rgba(255,255,255,0.5);">
                    LOGGED IN AS: <b style="color:white;"><?= strtoupper($user['firstName']) ?></b> 
                    (<?= $isAdmin ? 'ADMIN' : 'PLAYER' ?>)
                </span>
            </div>
        </div>
        <div>
            <a href="playerspage.php" class="nav-link">Players List</a>
            <a href="logout.php" class="btn-gold btn waves-effect">Logout</a>
        </div>
    </div>
    <div class="row">
        <div class="col s12 m4">
            <div class="glass-card">
                <h5 style="font-weight: 900; color: #F2B705;">STANDINGS</h5>
                <table class="centered">
                    <thead><tr><th>Rank</th><th>Player</th><th>Pts</th></tr></thead>
                    <tbody>
                        <?php $rank = 1; foreach($standings as $s): ?>
                        <tr>
                            <td style="font-weight:900; color:#F2B705;"><?=$rank++?></td>
                            <td><?=strtoupper($s['firstName'])?></td>
                            <td style="background:rgba(242,183,5,0.2);"><?= $s['total_pts'] ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col s12 m8">
            <div class="glass-card">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                    <h5 style="font-weight: 900; color: #F2B705; margin: 0; letter-spacing: 2px;">PAIRING</h5>
                    <?php if($isAdmin): ?>
                    <div style="display: flex; gap: 8px;">
                        <button onclick="generatePairs(<?= $nextRoundToGenerate ?>)" class="btn-small btn-gold waves-effect" style="border-radius: 8px; font-weight: 800; font-size: 0.7rem; height: 32px; line-height: 32px;">
                            <i class="material-icons left" style="font-size: 1.1rem; margin-right: 4px;">bolt</i> 
                            GENERATE ROUND <?= $nextRoundToGenerate ?>
                        </button>
                        <button onclick="resetTournament()" class="btn-small waves-effect red darken-4" style="border-radius: 8px; font-weight: 800; font-size: 0.7rem; height: 32px; line-height: 32px;">
                            <i class="material-icons left" style="font-size: 1.1rem; margin-right: 4px;">history</i> 
                            RESET PAIRINGS
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
                <div style="margin-bottom: 25px; display: flex; flex-wrap: wrap; gap: 8px; justify-content: center;">
                    <?php for($r = 1; $r <= 7; $r++): ?>
                    <a href="?round=<?= $r ?>" class="btn-small <?= $currentRound == $r ? 'btn-gold' : 'grey darken-3' ?>" style="border-radius: 5px; font-weight: 800; min-width: 45px;">R<?= $r ?></a>
                    <?php endfor; ?>
                </div>
                <div style="text-align: center; margin-bottom: 20px; border-bottom: 1px solid rgba(242,183,5,0.2); padding-bottom: 10px;">
                    <h6 style="font-weight: 400; color: #F2B705; letter-spacing: 4px; text-transform: uppercase; font-size: 0.9rem; margin: 0;">— ROUND <?= $currentRound ?> —</h6>
                </div>
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr>
                            <th style="width: 35%; text-align: center;">WHITE</th>
                            <th style="width: 30%; text-align: center;">RESULT</th>
                            <th style="width: 35%; text-align: center;">BLACK</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($pairings)): ?>
                        <tr><td colspan="3" style="text-align:center; padding: 40px; color: rgba(255,255,255,0.2);">No matches for Round <?= $currentRound ?>.</td></tr>
                        <?php else: ?>
                        <?php foreach($pairings as $m): ?>
                        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                            <td style="width: 35%; text-align: center; font-weight: 700; padding: 15px 0;"><?= strtoupper($m['p1Name']) ?></td>
                            <td style="width: 30%; text-align: center;">
                                <div style="display: flex; align-items: center; justify-content: center; gap: 10px;">
                                    <?php if($isAdmin): ?>
                                    <input type="number" id="score1_<?= (int)$m['match_id'] ?>" value="<?= $m['p1_score'] ?>" class="score-input">
                                    <span style="color: #F2B705; font-weight: bold;">-</span>
                                    <input type="number" id="score2_<?= (int)$m['match_id'] ?>" value="<?= $m['p2_score'] ?>" class="score-input">
                                    <button onclick="updateScore(<?= (int)$m['match_id'] ?>)" class="btn-floating btn-small waves-effect waves-light btn-gold"><i class="material-icons" style="font-size: 18px;">save</i></button>
                                    <?php else: ?>
                                    <div style="background: rgba(255,255,255,0.05); padding: 5px 15px; border-radius: 20px; display: flex; align-items: center; gap: 12px;">
                                        <span style="font-size: 1.1rem; font-weight: 900; color: #F2B705;"><?= $m['p1_score'] ?></span>
                                        <span style="color: rgba(255,255,255,0.2); font-size: 0.7rem;">VS</span>
                                        <span style="font-size: 1.1rem; font-weight: 900; color: #F2B705;"><?= $m['p2_score'] ?></span>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td style="width: 35%; text-align: center; font-weight: 700; padding: 15px 0;"><?= strtoupper($m['p2Name']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div> 
        </div> 
    </div> 
</div> 
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="../script/service.js"></script>
</body>
</html>