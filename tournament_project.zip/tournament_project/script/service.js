$(document).ready(function(){
    $('.modal').modal(); 
});

function loginFunc() {
    let data = {
        choice: 'login',
        fn: $('#icon_LFName').val(),
        ln: $('#icon_LLName').val()
    };

    $.post('../controllers/controller.php', data, function(res) {
        if (res.trim() == "true") {
            window.location.href = "dashboardpage.php"; 
        } else {
            Swal.fire("Error", "Login Failed", "error");
        }
    });
}

function addFunc() {
    let fn = $('#FName').val();
    let ln = $('#LName').val();
    let gd = $('#Gender').val();
    let ag = $('#Age').val();
    let rt = $('#Rating').val();

    if (!fn || !ln || !gd || !ag || !rt) {
        Swal.fire("Wait", "Complete the details, boi!", "warning");
        return;
    }

    let data = {
        choice: 'registerPlayer',
        fn: fn, ln: ln, gd: gd, ag: ag, rt: rt
    };

    $.post('../controllers/controller.php', data, function(res) {
        if (res.trim() == "true") {
            Swal.fire("Success", "Player Registered!", "success").then(() => {
                location.reload();
            });
        } else {
            Swal.fire("Error", "Registration failed: " + res, "error");
        }
    });
}

function openEditModal(id, fn, ln, age, rt) {
    $('#editID').val(id);
    $('#editFName').val(fn);
    $('#editLName').val(ln);
    $('#editAge').val(age);
    $('#editRating').val(rt);
    M.Modal.getInstance(document.getElementById('modalEdit')).open();
}

function updateFunc() {
    let data = {
        choice: "updateUser",
        id: $('#editID').val(),
        fn: $('#editFName').val(),
        ln: $('#editLName').val(),
        ag: $('#editAge').val(),
        rt: $('#editRating').val()
    };

    $.post("../controllers/controller.php", data, function(res) {
        if (res.trim() === "true") {
            Swal.fire("Success", "Player details updated and logged!", "success")
                .then(() => location.reload());
        } else {
            Swal.fire("Error", "Update failed: " + res, "error");
        }
    });
}

function generatePairs(roundNum) { 
    Swal.fire({
        title: 'Generate Round ' + roundNum + '?',
        text: "This will create pairings for this specific round.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#F2B705',
        confirmButtonText: 'Yes, Generate!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: '../controllers/controller.php',
                type: 'POST',
                data: {
                    choice: 'generatePairs',
                    round: roundNum
                },
                success: function(response) {
                    if (response.trim() == "true") {
                        Swal.fire('Success!', 'Matches generated.', 'success')
                        .then(() => location.reload());
                    } else {
                        Swal.fire('Error', response, 'error');
                    }
                }
            });
        }
    });
}

function updateScore(mid) {
    var input1 = document.getElementById("score1_" + mid);
    var input2 = document.getElementById("score2_" + mid);

    if (!input1 || !input2) {
        return;
    }

    var s1_val = input1.value;
    var s2_val = input2.value;

    $.ajax({
        url: "../controllers/controller.php",
        type: "POST",
        data: {
            choice: 'updateScore',
            mID: mid,
            s1: s1_val,
            s2: s2_val
        },
        success: function(res) {
            if (res.trim().includes("true")) {
                location.reload();
            } else {
                alert("Error: " + res);
            }
        }
    });
}

function deleteFunc(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#F2B705',
        cancelButtonColor: '#A6290D',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: '../controllers/controller.php',
                type: 'POST',
                data: {
                    choice: 'deletePlayer',
                    userID: id
                },
                success: function(res) {
                    if(res.trim() == "true") {
                        Swal.fire('Deleted!', 'Player has been removed.', 'success')
                        .then(() => location.reload());
                    } else {
                        Swal.fire('Error', 'Something went wrong!', 'error');
                    }
                }
            });
        }
    })
}

function registerAdmin() {
    if ($('#AdminSecretKey').val() !== "miffyandboris") {
        Swal.fire("Unauthorized", "Invalid Secret Key", "error");
        return;
    }

    let data = {
        choice: 'registerAdmin',
        id: $('#AdminID').val(),
        fn: $('#AdminFName').val(),
        ln: $('#AdminLName').val()
    };

    if(!data.id || !data.fn || !data.ln) {
        Swal.fire("Wait", "Please fill in all fields", "warning");
        return;
    }

    $.post('../controllers/controller.php', data, function(res) {
        if (res.trim() === "true") {
            Swal.fire("Success", "Admin Identity Verified!", "success").then(() => {
                window.location.href = "dashboardpage.php"; 
            });
        } else {
            Swal.fire("Error", "Registration failed: " + res, "error");
        }
    });
}

function registerPlayer() {
    let data = {
        choice: 'registerPlayer',
        fn: $('#regFN').val(),
        ln: $('#regLN').val(),
        gd: $('#regGender').val(),
        ag: $('#regAge').val(),
        rt: $('#regRating').val()
    };

    $.post('../controllers/controller.php', data, function(res) {
        if (res.trim() === "true") {
            Swal.fire("Registered!", "You can now login.", "success").then(() => {
                location.reload();
            });
        } else {
            Swal.fire("Error", "Registration failed", "error");
        }
    });
}

function resetTournament() {
    Swal.fire({
        title: 'Reset Tournament Pairings?',
        text: "This will delete all current matches and reset scores to zero.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, Reset Now',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: '../controllers/controller.php',
                type: 'POST',
                data: { choice: 'resetTournament' },
                success: function(res) {
                    if (res.trim() == "true") {
                        Swal.fire(
                            'Reset Successful!',
                            'All pairings have been cleared. You can now generate Round 1 again.',
                            'success'
                        ).then(() => {
                            location.href = "dashboardpage.php?round=1";
                        });
                    } else {
                        Swal.fire('Error', 'Server responded: ' + res, 'error');
                    }
                },
                error: function() {
                    Swal.fire('System Error', 'Failed to connect to the controller.', 'error');
                }
            });
        }
    });
}