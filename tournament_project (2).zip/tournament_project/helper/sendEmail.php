<?php
require_once __DIR__ . '/../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Load config
$config = require __DIR__ . '/../config/config.php';

function sendEmail($toEmail, $toName, $subject, $body) {
    global $config; 

    $mail = new PHPMailer(true);

    try {
        // SMTP Settings
        // $mail->SMTPDebug = 2; // UNCOMMENT THIS ONLY IF IT STILL FAILS TO SEE LOGS IN NETWORK TAB
        $mail->isSMTP();
        $mail->Host       = $config['host'];
        $mail->SMTPAuth   = true;
        $mail->Username   = $config['username'];
        $mail->Password   = $config['password'];
        
        /** * Logic fix for SSL/TLS:
         * If using port 465, PHPMailer works best with 'ssl'.
         * If using port 587, it uses 'tls'.
         */
        $mail->SMTPSecure = $config['encryption']; 
        $mail->Port       = $config['port'];

        // BYPASS SSL (Crucial for Localhost/XAMPP)
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );

        // Recipients
        $mail->setFrom($config['from_email'], $config['from_name']);
        $mail->addAddress($toEmail, $toName);

        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;
        $mail->AltBody = strip_tags($body);

        $mail->send();
        return true;

    } catch (Exception $e) {
        return $mail->ErrorInfo;
    }
}