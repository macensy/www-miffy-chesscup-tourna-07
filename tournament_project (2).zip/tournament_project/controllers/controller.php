<?php
session_start();
require_once "../bl/usermanager.php";
require_once "../helper/sendEmail.php"; 

$manager = new usermanager();
$choice = $_POST['choice'] ?? '';

// 1. LOGIN
if ($choice == "login") {
    $fn = $_POST['fn'] ?? '';
    $ln = $_POST['ln'] ?? '';
    $res = $manager->login($fn, $ln);
    echo ($res) ? "true" : "false";
    exit();
}

// 2. REGISTER PLAYER (WITH EMAIL)
if ($choice == "registerPlayer") {
    $fn = $_POST['fn'] ?? '';
    $ln = $_POST['ln'] ?? '';
    $gd = $_POST['gd'] ?? 'N/A';
    $ag = $_POST['ag'] ?? 0;
    $rt = $_POST['rt'] ?? 0;
    $role = 'Player'; 

    $res = $manager->registerPlayer($fn, $ln, $gd, $ag, $rt, $role);
    
    if ($res === true) {
        $name = htmlspecialchars("$fn $ln");
        $body = "<h3>New Registration</h3><p>Name: $name</p>";

        // Send notification to Admin
        $mailStatus = sendEmail(
            "peyttabungar@gmail.com",
            "Admin",
            "New Player Registered: $name",
            $body
        );

        ob_clean(); 
        if ($mailStatus === true) {
            echo "true"; 
        } else {
            echo "Email Error: " . $mailStatus; 
        }
    } else {
        echo $res; 
    }
    exit();
}

// 3. REGISTER ADMIN
if ($choice == "registerAdmin") {
    $fn = $_POST['fn'] ?? '';
    $ln = $_POST['ln'] ?? '';
    $id = rand(100000, 999999); 
    $role = 'Admin';

    $res = $manager->registerAdminFunc($id, $fn, $ln, $role);

    if ($res === true) {
        $_SESSION['user'] = [
            'userID' => $id,
            'firstName' => $fn,
            'lastName' => $ln,
            'role' => $role
        ];
        echo "true";
    } else {
        echo $res; 
    }
    exit();
}

// 4. UPDATE USER
if ($choice == "updateUser") {
    $id = $_POST['id'] ?? 0;
    $fn = $_POST['fn'] ?? '';
    $ln = $_POST['ln'] ?? '';
    $ag = $_POST['ag'] ?? 0;
    $rt = $_POST['rt'] ?? 0;
    
    echo $manager->updateUserFunc($id, $fn, $ln, $ag, $rt) ? "true" : "false";
    exit();
}

// 5. DELETE PLAYER
if ($choice == "deletePlayer") {
    $id = $_POST['userID'] ?? 0;
    echo $manager->deleteUser($id) ? "true" : "false";
    exit();
}

// 6. GENERATE PAIRS
if ($choice == 'generatePairs') {
    $round = $_POST['round'] ?? 1;
    $user = $_SESSION['user'] ?? null;
    $isAdmin = (isset($user['role']) && strcasecmp($user['role'], 'Admin') == 0);

    if (!$isAdmin) { 
        die("Unauthorized: Admin access only."); 
    }

    $res = $manager->generatePairingFunc($round);
    ob_clean(); 
    echo ($res === true) ? "true" : $res;
    exit();
}

// 7. UPDATE SCORE
if ($choice == 'updateScore') {
    $mid = $_POST['mID'] ?? 0; 
    $s1  = $_POST['s1'] ?? 0;
    $s2  = $_POST['s2'] ?? 0;

    $res = $manager->updateScoreFunc($mid, $s1, $s2);
    
    if ($res === "true" || $res === true) {
        echo "true";
    } else {
        echo $res; 
    }
    exit();
}

// 8. RESET TOURNAMENT
if ($choice == 'resetTournament') {
    $res = $manager->resetTournamentFunc();
    echo ($res === true) ? "true" : $res;
    exit();
}
?>