<?php

return [
    'host' => 'smtp.gmail.com',
    'username' => 'miffycctourna@gmail.com',
    'password' => 'njzbczqgvpwwouhi',
    'port' => 587,
    'encryption' => 'tls',
    'from_email' => 'miffycctourna@gmail.com',
    'from_name' => 'Miffy Chess Cup Tournament'

];


